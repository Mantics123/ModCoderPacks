#!/bin/bash
python runtime/decompile.py "$@"
