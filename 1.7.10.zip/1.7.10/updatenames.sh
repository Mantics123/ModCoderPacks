#!/bin/bash
python runtime/updatenames.py "$@"
