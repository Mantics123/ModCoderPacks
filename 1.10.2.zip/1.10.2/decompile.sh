#!/bin/bash
./runtime/decompile.py "$@"
